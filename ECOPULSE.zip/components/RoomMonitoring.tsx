"use client";

import React, { useEffect, useRef, useState } from "react";
import {
  Activity,
  Wifi,
  WifiOff,
  Zap,
  ZapOff,
  Eye,
  Clock,
  RefreshCw,
  Radio,
} from "lucide-react";

interface Room {
  id: number;
  name: string;
  department_id: number;
  status: "ON" | "OFF";
  last_occupied_time: string | null;
  cctv_stream_url: string | null;
  empty_seconds: number;
}

interface OccupancyResult {
  room_id: number;
  room_name: string;
  occupied: boolean;
  person_count: number;
  confidence: string;
  description: string;
  empty_seconds?: number;
  relay?: { action: string; topic: string };
}

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export default function RoomMonitoring() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [events, setEvents] = useState<OccupancyResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState<number | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const fileRefs = useRef<Record<number, HTMLInputElement | null>>({});

  // Fetch room list
  const fetchRooms = async () => {
    try {
      const res = await fetch(`${API}/api/rooms`);
      const data: Room[] = await res.json();
      setRooms(data);
    } catch {
      /* network unavailable in demo */
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRooms();
    // WebSocket live feed
    try {
      const ws = new WebSocket(`${API.replace("http", "ws")}/ws/rooms`);
      ws.onmessage = (e) => {
        const msg = JSON.parse(e.data);
        if (msg.event === "occupancy_update") {
          setEvents((prev) => [msg.data, ...prev].slice(0, 30));
          setRooms((prev) =>
            prev.map((r) =>
              r.id === msg.data.room_id
                ? {
                    ...r,
                    status: msg.data.occupied ? "ON" : r.status,
                    last_occupied_time: msg.data.occupied
                      ? new Date().toISOString()
                      : r.last_occupied_time,
                  }
                : r
            )
          );
        }
        if (msg.event === "snapshot") {
          setRooms(msg.data);
        }
      };
      wsRef.current = ws;
    } catch {
      /* WS not available */
    }
    return () => wsRef.current?.close();
  }, []);

  const handleFileUpload = async (roomId: number, file: File) => {
    setAnalyzing(roomId);
    const form = new FormData();
    form.append("frame", file);
    try {
      const res = await fetch(`${API}/api/rooms/${roomId}/analyze`, {
        method: "POST",
        body: form,
      });
      const data: OccupancyResult = await res.json();
      setEvents((prev) => [data, ...prev].slice(0, 30));
      await fetchRooms();
    } catch {
      /* network */
    } finally {
      setAnalyzing(null);
    }
  };

  const toggleRelay = async (room: Room) => {
    const action = room.status === "ON" ? "POWER_OFF" : "POWER_ON";
    try {
      await fetch(`${API}/api/rooms/${room.id}/relay`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      await fetchRooms();
    } catch {
      /* network */
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">
            Live Room Monitoring & Control
          </h2>
          <p className="text-sm text-gray-500 mt-0.5">
            AI-powered occupancy detection with automated IoT relay switching
          </p>
        </div>
        <button
          onClick={fetchRooms}
          className="flex items-center gap-2 px-3 py-1.5 text-sm bg-white border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {/* Room Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-44 bg-gray-100 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {rooms.map((room) => (
            <RoomCard
              key={room.id}
              room={room}
              analyzing={analyzing === room.id}
              onFileUpload={(file) => handleFileUpload(room.id, file)}
              onToggleRelay={() => toggleRelay(room)}
              fileRef={(el) => (fileRefs.current[room.id] = el)}
            />
          ))}
        </div>
      )}

      {/* Live Event Feed */}
      <div>
        <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
          <Radio size={14} className="text-green-500 animate-pulse" />
          Live AI Analysis Feed
        </h3>
        {events.length === 0 ? (
          <p className="text-sm text-gray-400 italic">
            Upload a room frame above to start analysis…
          </p>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {events.map((ev, i) => (
              <div
                key={i}
                className="flex items-start gap-3 bg-white border border-gray-100 rounded-lg p-3 text-sm"
              >
                <span
                  className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${
                    ev.occupied ? "bg-green-400" : "bg-gray-300"
                  }`}
                />
                <div className="flex-1 min-w-0">
                  <span className="font-medium">{ev.room_name}</span>
                  <span className="text-gray-500 mx-1">—</span>
                  <span
                    className={ev.occupied ? "text-green-600" : "text-gray-500"}
                  >
                    {ev.occupied
                      ? `${ev.person_count} person(s) detected`
                      : "Empty"}
                  </span>
                  {ev.relay && (
                    <span
                      className={`ml-2 px-2 py-0.5 rounded text-xs font-semibold ${
                        ev.relay.action === "POWER_ON"
                          ? "bg-green-100 text-green-700"
                          : "bg-orange-100 text-orange-700"
                      }`}
                    >
                      {ev.relay.action}
                    </span>
                  )}
                  <p className="text-gray-400 text-xs mt-0.5 truncate">
                    {ev.description}
                  </p>
                </div>
                <span className="text-xs text-gray-400 flex-shrink-0">
                  {ev.confidence}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function RoomCard({
  room,
  analyzing,
  onFileUpload,
  onToggleRelay,
  fileRef,
}: {
  room: Room;
  analyzing: boolean;
  onFileUpload: (f: File) => void;
  onToggleRelay: () => void;
  fileRef: (el: HTMLInputElement | null) => void;
}) {
  const isOn = room.status === "ON";
  return (
    <div
      className={`relative rounded-xl border p-4 transition-all ${
        isOn
          ? "border-green-200 bg-green-50/40"
          : "border-gray-200 bg-white"
      }`}
    >
      {/* Status badge */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span
            className={`w-2.5 h-2.5 rounded-full ${
              isOn ? "bg-green-400 animate-pulse" : "bg-gray-300"
            }`}
          />
          <span className="font-semibold text-gray-800 text-sm">
            {room.name}
          </span>
        </div>
        <span
          className={`text-xs font-bold px-2 py-0.5 rounded-full ${
            isOn
              ? "bg-green-100 text-green-700"
              : "bg-gray-100 text-gray-500"
          }`}
        >
          {room.status}
        </span>
      </div>

      {/* CCTV placeholder */}
      <div className="relative rounded-lg overflow-hidden bg-gray-900 aspect-video mb-3 flex items-center justify-center">
        <Eye size={20} className="text-gray-600" />
        <span className="text-gray-600 text-xs ml-2 font-mono">
          {room.cctv_stream_url?.split("/").pop() ?? "NO FEED"}
        </span>
        {isOn && (
          <span className="absolute top-2 right-2 flex items-center gap-1 bg-red-600 text-white text-xs px-1.5 py-0.5 rounded">
            <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
            LIVE
          </span>
        )}
      </div>

      {/* Last occupied */}
      {room.last_occupied_time && (
        <p className="text-xs text-gray-400 flex items-center gap-1 mb-3">
          <Clock size={11} />
          Last occupied{" "}
          {new Date(room.last_occupied_time).toLocaleTimeString()}
        </p>
      )}

      {/* Actions */}
      <div className="flex gap-2">
        {/* Upload frame for AI analysis */}
        <label className="flex-1 cursor-pointer">
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) =>
              e.target.files?.[0] && onFileUpload(e.target.files[0])
            }
          />
          <span
            className={`flex items-center justify-center gap-1 w-full py-1.5 rounded-lg text-xs font-medium border transition-colors ${
              analyzing
                ? "bg-blue-50 border-blue-200 text-blue-500 cursor-wait"
                : "bg-white border-gray-200 text-gray-600 hover:bg-blue-50 hover:border-blue-200"
            }`}
          >
            {analyzing ? (
              <>
                <Activity size={12} className="animate-spin" />
                Analyzing…
              </>
            ) : (
              <>
                <Activity size={12} />
                Analyze Frame
              </>
            )}
          </span>
        </label>

        {/* Manual relay toggle */}
        <button
          onClick={onToggleRelay}
          title={isOn ? "Turn OFF" : "Turn ON"}
          className={`flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${
            isOn
              ? "bg-orange-50 border-orange-200 text-orange-600 hover:bg-orange-100"
              : "bg-green-50 border-green-200 text-green-600 hover:bg-green-100"
          }`}
        >
          {isOn ? <ZapOff size={12} /> : <Zap size={12} />}
          {isOn ? "OFF" : "ON"}
        </button>
      </div>
    </div>
  );
}
