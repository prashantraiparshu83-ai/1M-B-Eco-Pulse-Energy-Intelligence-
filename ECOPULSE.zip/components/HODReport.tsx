"use client";

import React, { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  FileText,
  Download,
  Mail,
  Loader2,
  Leaf,
  DollarSign,
  Zap,
  Coins,
  Calendar,
  CheckCircle,
} from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

interface Report {
  id?: number;
  report_id?: number;
  date: string;
  department?: string;
  kwh_consumed: number;
  kwh_saved: number;
  cost_saved: number;
  co2_reduced: number;
  credits_earned: number;
  credit_balance?: number;
  summary: string | null;
  redeemable_products?: Array<{ name: string; required_credits: number }>;
}

interface Department {
  id: number;
  name: string;
  credit_balance: number;
}

export default function HODReport() {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedDept, setSelectedDept] = useState<number>(1);
  const [generating, setGenerating] = useState(false);
  const [currentReport, setCurrentReport] = useState<Report | null>(null);
  const [history, setHistory] = useState<Report[]>([]);
  const [activeHistoryId, setActiveHistoryId] = useState<number | null>(null);

  const fetchDepts = async () => {
    try {
      const res = await fetch(`${API}/api/departments`);
      const data: Department[] = await res.json();
      setDepartments(data);
      if (data.length > 0) setSelectedDept(data[0].id);
    } catch {
      setDepartments(DEMO_DEPTS);
    }
  };

  const fetchHistory = async (deptId: number) => {
    try {
      const res = await fetch(`${API}/api/reports/${deptId}?limit=7`);
      setHistory(await res.json());
    } catch {
      setHistory(DEMO_HISTORY);
    }
  };

  useEffect(() => {
    fetchDepts();
  }, []);

  useEffect(() => {
    fetchHistory(selectedDept);
  }, [selectedDept]);

  const handleGenerate = async () => {
    setGenerating(true);
    setCurrentReport(null);
    try {
      const res = await fetch(`${API}/api/reports/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ department_id: selectedDept }),
      });
      const data: Report = await res.json();
      setCurrentReport(data);
      await fetchHistory(selectedDept);
      await fetchDepts();
    } catch {
      // Demo fallback
      setCurrentReport(DEMO_REPORT);
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadMd = () => {
    if (!currentReport) return;
    const md = buildMarkdownReport(currentReport);
    const blob = new Blob([md], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `EcoPulse_Report_${currentReport.date}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const chartData = history.slice(0, 7).reverse().map((r) => ({
    date: r.date.slice(0, 10),
    "kWh Consumed": r.kwh_consumed,
    "kWh Saved": r.kwh_saved,
  }));

  const displayedReport = currentReport;
  const activeDept = departments.find((d) => d.id === selectedDept);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <FileText size={20} className="text-indigo-500" />
            HOD End-of-Day Report Generator
          </h2>
          <p className="text-sm text-gray-500 mt-0.5">
            IBM Granite RAG engine summarizes daily energy performance, savings &
            sustainability impact
          </p>
        </div>

        {/* Generate button */}
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-60 text-white font-semibold px-5 py-2.5 rounded-xl transition-colors shadow-sm"
        >
          {generating ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Generating Report…
            </>
          ) : (
            <>
              <FileText size={16} />
              Generate HOD Report
            </>
          )}
        </button>
      </div>

      {/* Dept selector */}
      <div className="flex items-center gap-3">
        <label className="text-sm font-medium text-gray-600">Department:</label>
        <select
          className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-200"
          value={selectedDept}
          onChange={(e) => setSelectedDept(Number(e.target.value))}
        >
          {departments.map((d) => (
            <option key={d.id} value={d.id}>
              {d.name}
            </option>
          ))}
        </select>
        {activeDept && (
          <span className="text-xs text-gray-500">
            Balance:{" "}
            <strong>{activeDept.credit_balance.toFixed(0)}</strong> credits
          </span>
        )}
      </div>

      {/* Historic chart */}
      {chartData.length > 0 && (
        <div className="bg-white border border-gray-100 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">
            7-Day Energy History
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} unit=" kWh" />
              <Tooltip formatter={(v: number) => `${v.toFixed(2)} kWh`} />
              <Bar dataKey="kWh Consumed" fill="#6366f1" radius={[3, 3, 0, 0]} />
              <Bar dataKey="kWh Saved" fill="#10b981" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Report output */}
      {generating && (
        <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-8 flex flex-col items-center gap-3">
          <Loader2 size={28} className="text-indigo-500 animate-spin" />
          <p className="text-sm text-indigo-700 font-medium">
            IBM Granite RAG engine is analyzing energy data…
          </p>
          <p className="text-xs text-indigo-500">
            Querying vector store · Aggregating meter readings · Generating
            summary
          </p>
        </div>
      )}

      {displayedReport && !generating && (
        <div className="bg-white border border-indigo-100 rounded-xl overflow-hidden shadow-sm">
          {/* Report header bar */}
          <div className="bg-indigo-600 text-white px-6 py-4 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-lg">EcoPulse Daily Report</h3>
              <p className="text-indigo-200 text-sm">
                {displayedReport.department ?? activeDept?.name} —{" "}
                {displayedReport.date.slice(0, 10)}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleDownloadMd}
                className="flex items-center gap-1.5 bg-white/20 hover:bg-white/30 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors"
              >
                <Download size={13} />
                Download .md
              </button>
            </div>
          </div>

          {/* KPI row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-0 divide-x divide-y divide-gray-100 border-b border-gray-100">
            {[
              {
                label: "kWh Consumed",
                value: displayedReport.kwh_consumed.toFixed(2),
                unit: "kWh",
                icon: <Zap size={14} className="text-yellow-500" />,
              },
              {
                label: "kWh Saved",
                value: displayedReport.kwh_saved.toFixed(2),
                unit: "kWh",
                icon: <Leaf size={14} className="text-green-500" />,
              },
              {
                label: "Cost Saved",
                value: `$${displayedReport.cost_saved.toFixed(2)}`,
                unit: "",
                icon: <DollarSign size={14} className="text-blue-500" />,
              },
              {
                label: "CO₂ Reduced",
                value: displayedReport.co2_reduced.toFixed(3),
                unit: "kg",
                icon: <Leaf size={14} className="text-emerald-500" />,
              },
            ].map((kpi) => (
              <div key={kpi.label} className="p-4 flex items-start gap-2">
                <div className="mt-0.5">{kpi.icon}</div>
                <div>
                  <p className="text-xs text-gray-500">{kpi.label}</p>
                  <p className="text-lg font-bold text-gray-900 leading-tight">
                    {kpi.value}
                    {kpi.unit && (
                      <span className="text-xs font-normal text-gray-500 ml-1">
                        {kpi.unit}
                      </span>
                    )}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Credits row */}
          <div className="flex flex-wrap gap-4 px-6 py-4 border-b border-gray-100 bg-yellow-50/40">
            <div className="flex items-center gap-2">
              <Coins size={16} className="text-yellow-500" />
              <span className="text-sm text-gray-700">
                Credits earned today:{" "}
                <strong>{displayedReport.credits_earned.toFixed(0)}</strong>
              </span>
            </div>
            {displayedReport.credit_balance !== undefined && (
              <div className="flex items-center gap-2">
                <Coins size={16} className="text-green-500" />
                <span className="text-sm text-gray-700">
                  Account balance:{" "}
                  <strong>
                    {displayedReport.credit_balance.toFixed(0)}
                  </strong>{" "}
                  credits
                </span>
              </div>
            )}
          </div>

          {/* AI Summary */}
          {displayedReport.summary && (
            <div className="px-6 py-5">
              <h4 className="text-sm font-semibold text-gray-700 mb-3">
                AI-Generated Executive Summary
              </h4>
              <div className="prose prose-sm max-w-none text-gray-700 bg-gray-50 rounded-lg px-5 py-4 leading-relaxed whitespace-pre-line text-sm">
                {displayedReport.summary}
              </div>
            </div>
          )}

          {/* Redeemable products */}
          {displayedReport.redeemable_products &&
            displayedReport.redeemable_products.length > 0 && (
              <div className="px-6 pb-5">
                <h4 className="text-sm font-semibold text-gray-700 mb-3">
                  Recommended Eco-Marketplace Deals
                </h4>
                <div className="space-y-2">
                  {displayedReport.redeemable_products.map((p, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-3 bg-green-50 border border-green-100 rounded-lg px-4 py-2"
                    >
                      <CheckCircle size={14} className="text-green-500" />
                      <span className="text-sm text-gray-800">{p.name}</span>
                      <span className="ml-auto text-xs text-green-700 font-medium">
                        {p.required_credits} credits
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
        </div>
      )}

      {/* History list */}
      {history.length > 0 && (
        <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
            <Calendar size={14} className="text-gray-500" />
            <h3 className="text-sm font-semibold text-gray-700">
              Previous Reports
            </h3>
          </div>
          <div className="divide-y divide-gray-50">
            {history.map((r, i) => (
              <div
                key={i}
                className="px-5 py-3 flex items-center gap-4 hover:bg-gray-50/50 cursor-pointer"
                onClick={() => setCurrentReport(r)}
              >
                <span className="text-xs font-mono text-gray-400 w-24 flex-shrink-0">
                  {r.date.slice(0, 10)}
                </span>
                <span className="text-sm text-gray-700 flex-1">
                  {r.kwh_saved.toFixed(2)} kWh saved · ${r.cost_saved.toFixed(2)} ·{" "}
                  {r.co2_reduced.toFixed(2)} kg CO₂
                </span>
                <span className="text-xs text-yellow-600 font-semibold">
                  +{r.credits_earned.toFixed(0)} cr
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ---- Markdown builder ----
function buildMarkdownReport(r: Report): string {
  return `# EcoPulse Vision Guard — HOD End-of-Day Report

**Department:** ${r.department ?? "—"}  
**Date:** ${r.date.slice(0, 10)}  
**Generated by:** IBM Granite RAG Engine

---

## Energy Performance

| Metric | Value |
|--------|-------|
| kWh Consumed | ${r.kwh_consumed.toFixed(2)} kWh |
| kWh Saved | ${r.kwh_saved.toFixed(2)} kWh |
| Cost Saved | $${r.cost_saved.toFixed(2)} |
| CO₂ Reduced | ${r.co2_reduced.toFixed(3)} kg |
| Credits Earned Today | ${r.credits_earned.toFixed(0)} pts |
| Account Credit Balance | ${(r.credit_balance ?? 0).toFixed(0)} pts |

---

## AI Executive Summary

${r.summary ?? "No summary generated."}

---

## Recommended Eco-Marketplace Deals

${
  r.redeemable_products && r.redeemable_products.length > 0
    ? r.redeemable_products
        .map((p) => `- **${p.name}** — ${p.required_credits} credits`)
        .join("\n")
    : "_No redeemable products at current balance._"
}

---
*Powered by EcoPulse Vision Guard · IBM Granite AI · © ${new Date().getFullYear()}*
`;
}

// ---- Demo data ----
const DEMO_DEPTS: Department[] = [
  { id: 1, name: "Computer Science & Engineering", credit_balance: 523 },
  { id: 2, name: "Electrical Engineering", credit_balance: 892 },
];

const DEMO_HISTORY: Report[] = Array.from({ length: 5 }, (_, i) => ({
  date: new Date(Date.now() - i * 86400000).toISOString(),
  kwh_consumed: parseFloat((40 + Math.random() * 15).toFixed(2)),
  kwh_saved: parseFloat((5 + Math.random() * 8).toFixed(2)),
  cost_saved: parseFloat((0.6 + Math.random() * 1).toFixed(2)),
  co2_reduced: parseFloat((1 + Math.random() * 2).toFixed(3)),
  credits_earned: parseFloat((50 + Math.random() * 80).toFixed(0)),
  summary: null,
}));

const DEMO_REPORT: Report = {
  report_id: 99,
  date: new Date().toISOString(),
  department: "Computer Science & Engineering",
  kwh_consumed: 47.3,
  kwh_saved: 7.12,
  cost_saved: 0.85,
  co2_reduced: 1.659,
  credits_earned: 71,
  credit_balance: 594,
  summary: `## 1. Energy Performance Overview
The CSE department consumed 47.3 kWh today against a historical baseline of 54.4 kWh, achieving a 13.1% reduction. Automated CCTV-triggered relay shutdowns contributed approximately 68% of total savings.

## 2. Financial & Environmental Impact
Today's energy savings of 7.12 kWh translated to $0.85 in direct cost reductions and offset 1.659 kg of CO₂ — equivalent to planting 0.15 trees. The department is on track to reach its monthly carbon goal.

## 3. Loyalty Credits Summary
71 EcoPulse Credits were earned today, bringing the department's total balance to 594 credits (≈ $5.94 in redemption value). At current pace, 1,000 credits will be reached within 6 days.

## 4. Top Energy-Saving Recommendations
LAB-101 and AUDITORIUM-A show the highest unattended-energy risk during lunch hours (12:00–14:00). Recommend setting CCTV polling interval to 30s during peak off-hours. Installing motion-activated smart switches in corridors could yield an additional 10–15% savings.

## 5. Suggested Marketplace Redemptions
With 594 credits, the department can immediately redeem: Smart LED Strip (100 cr), Reusable Water Bottle (70 cr), and Recycled Office Paper (40 cr). Redeeming these three bundles would save $17.00 in supply costs.`,
  redeemable_products: [
    { name: "Smart LED Strip (5m)", required_credits: 100 },
    { name: "Reusable Water Bottle (BPA-Free)", required_credits: 70 },
    { name: "Recycled Office Paper (500 sheets)", required_credits: 40 },
  ],
};
