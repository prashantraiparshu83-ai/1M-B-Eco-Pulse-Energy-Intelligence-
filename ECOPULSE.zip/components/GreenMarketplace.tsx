"use client";

import React, { useEffect, useState } from "react";
import {
  ShoppingBag,
  Star,
  CheckCircle,
  Coins,
  Tag,
  RefreshCw,
  Package,
} from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

interface Product {
  id: number;
  product_name: string;
  description: string | null;
  original_price: number;
  credit_discount_price: number;
  required_credits: number;
  stock: number;
  category: string | null;
}

interface Department {
  id: number;
  name: string;
  hod_email: string;
  credit_balance: number;
}

const CATEGORY_COLORS: Record<string, string> = {
  Lighting: "bg-yellow-100 text-yellow-700",
  Appliances: "bg-blue-100 text-blue-700",
  Stationery: "bg-purple-100 text-purple-700",
  Electronics: "bg-indigo-100 text-indigo-700",
  Sustainability: "bg-green-100 text-green-700",
};

export default function GreenMarketplace() {
  const [products, setProducts] = useState<Product[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [selectedDept, setSelectedDept] = useState<number>(1);
  const [redeeming, setRedeeming] = useState<number | null>(null);
  const [redeemResult, setRedeemResult] = useState<string | null>(null);
  const [filterCategory, setFilterCategory] = useState<string>("");
  const [loading, setLoading] = useState(true);

  const activeDept = departments.find((d) => d.id === selectedDept);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [prodRes, deptRes] = await Promise.all([
        fetch(`${API}/api/marketplace${filterCategory ? `?category=${filterCategory}` : ""}`),
        fetch(`${API}/api/departments`),
      ]);
      setProducts(await prodRes.json());
      const depts: Department[] = await deptRes.json();
      setDepartments(depts);
      if (depts.length > 0) setSelectedDept(depts[0].id);
    } catch {
      // Demo fallback
      setProducts(DEMO_PRODUCTS);
      setDepartments(DEMO_DEPTS);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [filterCategory]);

  const handleRedeem = async (product: Product) => {
    if (!activeDept) return;
    if (activeDept.credit_balance < product.required_credits) {
      setRedeemResult(`❌ Insufficient credits (need ${product.required_credits}, have ${activeDept.credit_balance.toFixed(0)})`);
      return;
    }
    setRedeeming(product.id);
    setRedeemResult(null);
    try {
      const res = await fetch(`${API}/api/marketplace/redeem`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          department_id: selectedDept,
          product_id: product.id,
          quantity: 1,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setRedeemResult(
          `✅ Redeemed "${data.product}"! ${data.credits_spent} credits spent. Remaining: ${data.remaining_balance?.toFixed(0)} credits`
        );
        await fetchData();
      } else {
        setRedeemResult(`❌ ${data.detail ?? "Redemption failed"}`);
      }
    } catch {
      // Demo
      setRedeemResult(`✅ Demo: Redeemed "${product.product_name}" for ${product.required_credits} credits!`);
      setDepartments((prev) =>
        prev.map((d) =>
          d.id === selectedDept
            ? { ...d, credit_balance: Math.max(0, d.credit_balance - product.required_credits) }
            : d
        )
      );
    } finally {
      setRedeeming(null);
    }
  };

  const categories = [...new Set(products.map((p) => p.category).filter(Boolean))] as string[];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-semibold text-gray-900 flex items-center gap-2">
            <span className="text-green-500">🌿</span> Green Loyalty Marketplace
          </h2>
          <p className="text-sm text-gray-500 mt-0.5">
            Redeem EcoPulse Credits for eco-friendly campus supplies
          </p>
        </div>
        <button
          onClick={fetchData}
          className="flex items-center gap-2 px-3 py-1.5 text-sm bg-white border border-gray-200 rounded-lg hover:bg-gray-50"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {/* Credit Balance Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Department selector + balance */}
        <div className="lg:col-span-1 bg-gradient-to-br from-green-600 to-emerald-600 text-white rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Coins size={18} />
            <span className="text-sm font-semibold">Department Credits</span>
          </div>
          <select
            className="w-full bg-white/20 border border-white/30 rounded-lg px-3 py-1.5 text-white text-sm mb-3 focus:outline-none"
            value={selectedDept}
            onChange={(e) => setSelectedDept(Number(e.target.value))}
          >
            {departments.map((d) => (
              <option key={d.id} value={d.id} className="text-gray-900 bg-white">
                {d.name}
              </option>
            ))}
          </select>
          {activeDept && (
            <>
              <p className="text-3xl font-bold">
                {activeDept.credit_balance.toFixed(0)}
              </p>
              <p className="text-green-200 text-sm">EcoPulse Credits</p>
              <p className="text-xs text-green-200 mt-2">
                ≈ ${(activeDept.credit_balance / 100).toFixed(2)} in savings
              </p>
            </>
          )}
        </div>

        {/* Conversion info */}
        <div className="lg:col-span-2 grid grid-cols-3 gap-3">
          {[
            { label: "1 kWh Saved", value: "= 10 Credits", icon: "⚡" },
            { label: "100 Credits", value: "= $1.00 Savings", icon: "💰" },
            { label: "Exchange Rate", value: "1 Credit = $0.01", icon: "🌱" },
          ].map((item) => (
            <div
              key={item.label}
              className="bg-white border border-gray-100 rounded-xl p-4 text-center"
            >
              <div className="text-2xl mb-2">{item.icon}</div>
              <p className="text-xs text-gray-500">{item.label}</p>
              <p className="text-sm font-semibold text-gray-800 mt-1">
                {item.value}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Redeem result toast */}
      {redeemResult && (
        <div
          className={`px-4 py-3 rounded-lg text-sm font-medium ${
            redeemResult.startsWith("✅")
              ? "bg-green-50 text-green-700 border border-green-200"
              : "bg-red-50 text-red-700 border border-red-200"
          }`}
        >
          {redeemResult}
        </div>
      )}

      {/* Category filter */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setFilterCategory("")}
          className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
            filterCategory === ""
              ? "bg-gray-900 text-white border-gray-900"
              : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
          }`}
        >
          All
        </button>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setFilterCategory(cat)}
            className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
              filterCategory === cat
                ? "bg-gray-900 text-white border-gray-900"
                : "bg-white text-gray-600 border-gray-200 hover:bg-gray-50"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Product Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-56 bg-gray-100 rounded-xl animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((product) => {
            const canAfford =
              activeDept !== undefined &&
              activeDept.credit_balance >= product.required_credits;
            const savings = (product.original_price - product.credit_discount_price).toFixed(2);

            return (
              <div
                key={product.id}
                className={`bg-white border rounded-xl p-4 flex flex-col transition-all ${
                  canAfford
                    ? "border-green-200 hover:border-green-300 hover:shadow-sm"
                    : "border-gray-200 opacity-80"
                }`}
              >
                {/* Category badge */}
                <div className="flex items-start justify-between mb-3">
                  <span
                    className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      CATEGORY_COLORS[product.category ?? ""] ??
                      "bg-gray-100 text-gray-600"
                    }`}
                  >
                    {product.category ?? "General"}
                  </span>
                  {canAfford && (
                    <span className="text-xs text-green-600 font-medium flex items-center gap-1">
                      <CheckCircle size={12} />
                      Affordable
                    </span>
                  )}
                </div>

                {/* Product icon placeholder */}
                <div className="w-full aspect-square max-h-28 bg-gray-50 rounded-lg flex items-center justify-center mb-3">
                  <Package size={32} className="text-gray-300" />
                </div>

                <h4 className="font-semibold text-gray-900 text-sm mb-1">
                  {product.product_name}
                </h4>
                <p className="text-xs text-gray-500 flex-1 mb-3">
                  {product.description ?? "Eco-friendly campus supply"}
                </p>

                {/* Pricing */}
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="text-xs text-gray-400 line-through">
                      ${product.original_price.toFixed(2)}
                    </span>
                    <span className="text-sm font-bold text-green-700 ml-2">
                      ${product.credit_discount_price.toFixed(2)}
                    </span>
                  </div>
                  <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">
                    Save ${savings}
                  </span>
                </div>

                {/* Credits required */}
                <div className="flex items-center gap-1 text-sm text-gray-700 mb-3">
                  <Coins size={14} className="text-yellow-500" />
                  <span className="font-semibold">{product.required_credits}</span>
                  <span className="text-gray-400">credits</span>
                  <span className="ml-auto text-xs text-gray-400">
                    Stock: {product.stock}
                  </span>
                </div>

                <button
                  onClick={() => handleRedeem(product)}
                  disabled={!canAfford || redeeming === product.id}
                  className={`w-full py-2 rounded-lg text-sm font-semibold transition-colors ${
                    canAfford
                      ? "bg-green-600 hover:bg-green-700 text-white"
                      : "bg-gray-100 text-gray-400 cursor-not-allowed"
                  }`}
                >
                  {redeeming === product.id
                    ? "Redeeming…"
                    : canAfford
                    ? "Redeem Now"
                    : `Need ${product.required_credits - (activeDept?.credit_balance ?? 0)} more`}
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ---- Demo data ----
const DEMO_DEPTS: Department[] = [
  { id: 1, name: "Computer Science & Engineering", hod_email: "hod.cse@campus.edu", credit_balance: 450 },
  { id: 2, name: "Electrical Engineering", hod_email: "hod.ee@campus.edu", credit_balance: 820 },
];

const DEMO_PRODUCTS: Product[] = [
  { id: 1, product_name: "Smart LED Strip (5m)", description: "Energy Star certified LED strip", original_price: 24.99, credit_discount_price: 14.99, required_credits: 100, stock: 50, category: "Lighting" },
  { id: 2, product_name: "Energy Star Desktop Fan", description: "Low-power smart fan with occupancy sensor", original_price: 49.99, credit_discount_price: 34.99, required_credits: 150, stock: 30, category: "Appliances" },
  { id: 3, product_name: "Recycled Office Paper (500 sheets)", description: "100% post-consumer recycled A4 paper", original_price: 8.99, credit_discount_price: 4.99, required_credits: 40, stock: 200, category: "Stationery" },
  { id: 4, product_name: "Smart Power Strip (6-outlet)", description: "Auto-shutoff smart power strip", original_price: 39.99, credit_discount_price: 24.99, required_credits: 150, stock: 40, category: "Appliances" },
  { id: 5, product_name: "Solar Phone Charger", description: "Portable 10W solar charger", original_price: 29.99, credit_discount_price: 17.99, required_credits: 120, stock: 25, category: "Electronics" },
  { id: 6, product_name: "Reusable Water Bottle (BPA-Free)", description: "Stainless steel insulated bottle", original_price: 14.99, credit_discount_price: 7.99, required_credits: 70, stock: 100, category: "Sustainability" },
];
