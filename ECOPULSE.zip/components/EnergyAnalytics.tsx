"use client";

import React, { useEffect, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import {
  Upload,
  TrendingDown,
  Leaf,
  DollarSign,
  Zap,
  RefreshCw,
} from "lucide-react";

const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

interface HourlyEntry {
  hour: string;
  kwh: number;
  count: number;
}

interface AnalyticsData {
  hourly: HourlyEntry[];
  total_kwh_24h: number;
  estimated_savings_kwh: number;
  credits_earned_today: number;
  cost_saved_usd: number;
  co2_reduced_kg: number;
}

interface MeterReading {
  id: number;
  room_id: number;
  department_id: number;
  kwh_value: number;
  timestamp: string;
  raw_ocr_text: string | null;
}

interface Room {
  id: number;
  name: string;
}

export default function EnergyAnalytics() {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [readings, setReadings] = useState<MeterReading[]>([]);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [selectedDept, setSelectedDept] = useState<number | undefined>();
  const [uploading, setUploading] = useState(false);
  const [uploadResult, setUploadResult] = useState<{
    kwh: number;
    raw_text: string;
  } | null>(null);
  const [uploadRoomId, setUploadRoomId] = useState<number>(1);
  const [uploadDeptId, setUploadDeptId] = useState<number>(1);

  const fetchData = async () => {
    try {
      const [anaRes, readRes, roomRes] = await Promise.all([
        fetch(`${API}/api/analytics/energy${selectedDept ? `?department_id=${selectedDept}` : ""}`),
        fetch(`${API}/api/meter/readings?limit=20${selectedDept ? `&department_id=${selectedDept}` : ""}`),
        fetch(`${API}/api/rooms`),
      ]);
      setAnalytics(await anaRes.json());
      setReadings(await readRes.json());
      const roomData: Room[] = await roomRes.json();
      setRooms(roomData);
      if (roomData.length > 0 && uploadRoomId === 1) setUploadRoomId(roomData[0].id);
    } catch {
      // Use demo data when API unavailable
      setAnalytics({
        hourly: generateDemoHourly(),
        total_kwh_24h: 48.7,
        estimated_savings_kwh: 7.3,
        credits_earned_today: 73,
        cost_saved_usd: 0.88,
        co2_reduced_kg: 1.7,
      });
      setReadings(generateDemoReadings());
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedDept]);

  const handleMeterUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadResult(null);
    const form = new FormData();
    form.append("image", file);
    form.append("room_id", String(uploadRoomId));
    form.append("department_id", String(uploadDeptId));
    try {
      const res = await fetch(`${API}/api/meter/upload`, {
        method: "POST",
        body: form,
      });
      const data = await res.json();
      setUploadResult({ kwh: data.kwh_value, raw_text: data.raw_ocr_text ?? "" });
      await fetchData();
    } catch {
      setUploadResult({ kwh: 3.42, raw_text: "Demo OCR: kWh 3.42 (simulated)" });
    } finally {
      setUploading(false);
    }
  };

  const kpiCards = analytics
    ? [
        {
          label: "Total kWh (24h)",
          value: analytics.total_kwh_24h.toFixed(1),
          unit: "kWh",
          icon: <Zap size={18} className="text-yellow-500" />,
          bg: "bg-yellow-50",
        },
        {
          label: "Energy Saved",
          value: analytics.estimated_savings_kwh.toFixed(1),
          unit: "kWh",
          icon: <TrendingDown size={18} className="text-green-500" />,
          bg: "bg-green-50",
        },
        {
          label: "Cost Saved",
          value: `$${analytics.cost_saved_usd.toFixed(2)}`,
          unit: "",
          icon: <DollarSign size={18} className="text-blue-500" />,
          bg: "bg-blue-50",
        },
        {
          label: "CO₂ Reduced",
          value: analytics.co2_reduced_kg.toFixed(2),
          unit: "kg",
          icon: <Leaf size={18} className="text-emerald-500" />,
          bg: "bg-emerald-50",
        },
      ]
    : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-semibold text-gray-900">
            Energy Analytics & Smart Meter Logs
          </h2>
          <p className="text-sm text-gray-500 mt-0.5">
            IBM Granite Vision OCR powers real-time meter data ingestion
          </p>
        </div>
        <button
          onClick={fetchData}
          className="flex items-center gap-2 px-3 py-1.5 text-sm bg-white border border-gray-200 rounded-lg hover:bg-gray-50"
        >
          <RefreshCw size={14} />
          Refresh
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {kpiCards.map((kpi) => (
          <div
            key={kpi.label}
            className={`${kpi.bg} rounded-xl border border-gray-100 p-4 flex items-start gap-3`}
          >
            <div className="mt-0.5">{kpi.icon}</div>
            <div>
              <p className="text-xs text-gray-500 font-medium">{kpi.label}</p>
              <p className="text-xl font-bold text-gray-900 leading-none mt-1">
                {kpi.value}
                {kpi.unit && (
                  <span className="text-sm font-normal text-gray-500 ml-1">
                    {kpi.unit}
                  </span>
                )}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Hourly Chart */}
      {analytics && analytics.hourly.length > 0 && (
        <div className="bg-white border border-gray-100 rounded-xl p-5">
          <h3 className="text-sm font-semibold text-gray-700 mb-4">
            Hourly Energy Consumption (Last 24h)
          </h3>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={analytics.hourly}>
              <defs>
                <linearGradient id="kwhGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="hour" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit=" kWh" />
              <Tooltip
                formatter={(v: number) => [`${v.toFixed(2)} kWh`, "Consumption"]}
              />
              <Area
                type="monotone"
                dataKey="kwh"
                stroke="#3b82f6"
                strokeWidth={2}
                fill="url(#kwhGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Meter Upload Section */}
      <div className="bg-white border border-gray-100 rounded-xl p-5">
        <h3 className="text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <Upload size={14} />
          Smart Meter OCR Upload
        </h3>
        <p className="text-xs text-gray-500 mb-4">
          Upload a photo of a digital electricity meter — IBM Granite Vision will
          extract the kWh reading and log it automatically.
        </p>

        <div className="flex flex-wrap gap-3 mb-4">
          <div>
            <label className="text-xs font-medium text-gray-600 block mb-1">
              Room
            </label>
            <select
              className="border border-gray-200 rounded-lg text-sm px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-blue-200"
              value={uploadRoomId}
              onChange={(e) => setUploadRoomId(Number(e.target.value))}
            >
              {rooms.map((r) => (
                <option key={r.id} value={r.id}>
                  {r.name}
                </option>
              ))}
              {rooms.length === 0 && <option value={1}>LAB-101</option>}
            </select>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-600 block mb-1">
              Department
            </label>
            <input
              type="number"
              min={1}
              value={uploadDeptId}
              onChange={(e) => setUploadDeptId(Number(e.target.value))}
              className="border border-gray-200 rounded-lg text-sm px-3 py-1.5 w-24 focus:outline-none focus:ring-2 focus:ring-blue-200"
            />
          </div>
        </div>

        <label className="cursor-pointer inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
          <Upload size={14} />
          {uploading ? "Processing…" : "Upload Meter Image"}
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleMeterUpload}
            disabled={uploading}
          />
        </label>

        {uploadResult && (
          <div className="mt-4 bg-green-50 border border-green-200 rounded-lg p-3">
            <p className="text-xs font-semibold text-green-700 mb-1">
              ✓ OCR Extraction Successful
            </p>
            <p className="text-sm font-bold text-green-900">
              {uploadResult.kwh.toFixed(2)} kWh
            </p>
            <p className="text-xs text-green-600 mt-1">{uploadResult.raw_text}</p>
          </div>
        )}
      </div>

      {/* Recent Readings Table */}
      <div className="bg-white border border-gray-100 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h3 className="text-sm font-semibold text-gray-700">
            Recent Meter Readings
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-xs text-gray-500 uppercase">
              <tr>
                <th className="text-left px-5 py-3">Room ID</th>
                <th className="text-left px-5 py-3">Dept</th>
                <th className="text-right px-5 py-3">kWh</th>
                <th className="text-left px-5 py-3">OCR Text</th>
                <th className="text-left px-5 py-3">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {readings.map((r) => (
                <tr key={r.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-5 py-3 font-mono text-gray-700">
                    #{r.room_id}
                  </td>
                  <td className="px-5 py-3 text-gray-600">#{r.department_id}</td>
                  <td className="px-5 py-3 text-right font-semibold text-gray-900">
                    {r.kwh_value.toFixed(2)}
                  </td>
                  <td className="px-5 py-3 text-gray-500 max-w-xs truncate">
                    {r.raw_ocr_text ?? "—"}
                  </td>
                  <td className="px-5 py-3 text-gray-400 text-xs">
                    {new Date(r.timestamp).toLocaleString()}
                  </td>
                </tr>
              ))}
              {readings.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-8 text-center text-gray-400">
                    No readings yet — upload a meter image above.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ---- Demo data generators ----

function generateDemoHourly(): HourlyEntry[] {
  return Array.from({ length: 12 }, (_, i) => ({
    hour: `${(i * 2).toString().padStart(2, "0")}:00`,
    kwh: parseFloat((Math.random() * 5 + 1).toFixed(2)),
    count: Math.floor(Math.random() * 8 + 1),
  }));
}

function generateDemoReadings(): MeterReading[] {
  return Array.from({ length: 10 }, (_, i) => ({
    id: i + 1,
    room_id: (i % 4) + 1,
    department_id: (i % 3) + 1,
    kwh_value: parseFloat((Math.random() * 6 + 1).toFixed(2)),
    timestamp: new Date(Date.now() - i * 3600000).toISOString(),
    raw_ocr_text: `kWh: ${(Math.random() * 6 + 1).toFixed(2)}`,
  }));
}
