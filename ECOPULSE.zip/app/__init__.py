"""EcoPulse Vision Guard backend — package init."""
