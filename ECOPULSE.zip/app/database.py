"""
Database setup — SQLAlchemy session factory + pgvector/SQLite fallback.
Vector store helpers for meter-reading RAG using pgvector (PostgreSQL)
or an in-memory fallback dict for SQLite local dev.
"""

import os
import json
import hashlib
from typing import Optional, List, Dict

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, Session

from .models import Base

# -----------------------------------------------------------------------
# Primary relational DB
# -----------------------------------------------------------------------
DATABASE_URL: str = os.getenv(
    "DATABASE_URL",
    "sqlite:///./ecopulse.db"   # local dev default
)

# PostgreSQL needs psycopg2; SQLite uses built-in
engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {},
    echo=False,
    pool_pre_ping=True,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db() -> None:
    """Create all tables (idempotent)."""
    Base.metadata.create_all(bind=engine)

    # Enable pgvector extension if using PostgreSQL
    if "postgresql" in DATABASE_URL:
        with engine.connect() as conn:
            conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector;"))
            conn.commit()


def get_db():
    """FastAPI dependency — yields a database session."""
    db: Session = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# -----------------------------------------------------------------------
# Vector store helpers
# -----------------------------------------------------------------------
# Simple in-memory store for SQLite / dev. In production, swap for
# pgvector or Milvus calls via the client libraries.
_vector_store: Dict[str, Dict] = {}


def _embed_text(text_blob: str) -> List[float]:
    """
    Deterministic pseudo-embedding for local dev (no GPU needed).
    In production replace with ibm-watsonx-ai embeddings or sentence-transformers.
    """
    digest = hashlib.sha256(text_blob.encode()).digest()
    # 16-dim vector from the first 16 bytes of SHA-256
    return [b / 255.0 for b in digest[:16]]


def upsert_meter_vector(doc_id: str, kwh: float, timestamp: str, room_id: int,
                         raw_text: str) -> None:
    """Store a meter reading embedding in the vector store."""
    payload = {
        "doc_id": doc_id,
        "kwh": kwh,
        "timestamp": timestamp,
        "room_id": room_id,
        "raw_text": raw_text,
        "embedding": _embed_text(raw_text),
    }
    _vector_store[doc_id] = payload

    if "postgresql" in DATABASE_URL:
        # TODO: insert via psycopg2 + pgvector '<->' operator in production
        pass


def search_similar_readings(query_text: str, top_k: int = 5) -> List[Dict]:
    """
    Cosine-similarity retrieval from vector store.
    Returns top_k most-similar meter reading payloads.
    """
    query_vec = _embed_text(query_text)
    if not _vector_store:
        return []

    def cosine(a: List[float], b: List[float]) -> float:
        dot = sum(x * y for x, y in zip(a, b))
        na = sum(x ** 2 for x in a) ** 0.5
        nb = sum(x ** 2 for x in b) ** 0.5
        return dot / (na * nb + 1e-9)

    scored = [
        (cosine(query_vec, v["embedding"]), v)
        for v in _vector_store.values()
    ]
    scored.sort(key=lambda x: x[0], reverse=True)
    return [v for _, v in scored[:top_k]]
