"use client";

import React, { useState } from "react";
import {
  Camera,
  BarChart2,
  ShoppingBag,
  FileText,
  Zap,
  Leaf,
  Activity,
  Wifi,
} from "lucide-react";
import dynamic from "next/dynamic";

// Lazy-load tabs to avoid SSR issues with Recharts
const RoomMonitoring = dynamic(() => import("../components/RoomMonitoring"), {
  ssr: false,
  loading: () => <TabSkeleton />,
});
const EnergyAnalytics = dynamic(() => import("../components/EnergyAnalytics"), {
  ssr: false,
  loading: () => <TabSkeleton />,
});
const GreenMarketplace = dynamic(() => import("../components/GreenMarketplace"), {
  ssr: false,
  loading: () => <TabSkeleton />,
});
const HODReport = dynamic(() => import("../components/HODReport"), {
  ssr: false,
  loading: () => <TabSkeleton />,
});

const TABS = [
  {
    id: "rooms",
    label: "Room Monitoring",
    shortLabel: "Rooms",
    icon: Camera,
    color: "text-green-600",
    activeBg: "bg-green-50 border-green-300",
  },
  {
    id: "energy",
    label: "Energy Analytics",
    shortLabel: "Analytics",
    icon: BarChart2,
    color: "text-blue-600",
    activeBg: "bg-blue-50 border-blue-300",
  },
  {
    id: "marketplace",
    label: "Green Marketplace",
    shortLabel: "Market",
    icon: ShoppingBag,
    color: "text-emerald-600",
    activeBg: "bg-emerald-50 border-emerald-300",
  },
  {
    id: "report",
    label: "HOD Report",
    shortLabel: "Report",
    icon: FileText,
    color: "text-indigo-600",
    activeBg: "bg-indigo-50 border-indigo-300",
  },
] as const;

type TabId = (typeof TABS)[number]["id"];

function TabSkeleton() {
  return (
    <div className="space-y-4 animate-pulse">
      <div className="h-8 bg-gray-100 rounded-lg w-1/3" />
      <div className="grid grid-cols-3 gap-4">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="h-32 bg-gray-100 rounded-xl" />
        ))}
      </div>
      <div className="h-48 bg-gray-100 rounded-xl" />
    </div>
  );
}

export default function EcoPulsePage() {
  const [activeTab, setActiveTab] = useState<TabId>("rooms");

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* ─── Top Nav ─── */}
      <header className="sticky top-0 z-40 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Brand */}
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-sm">
                <Leaf size={18} className="text-white" />
              </div>
              <div>
                <h1 className="font-bold text-gray-900 text-base leading-none">
                  EcoPulse Vision Guard
                </h1>
                <p className="text-xs text-gray-400 leading-none mt-0.5">
                  Campus Energy Intelligence Platform
                </p>
              </div>
            </div>

            {/* Status pills */}
            <div className="hidden md:flex items-center gap-3">
              <StatusPill icon={<Wifi size={11} />} label="IoT Connected" color="green" />
              <StatusPill icon={<Activity size={11} />} label="Granite Vision" color="blue" />
              <StatusPill icon={<Zap size={11} />} label="RAG Active" color="purple" />
            </div>
          </div>
        </div>
      </header>

      {/* ─── Tab Bar ─── */}
      <nav className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-0 overflow-x-auto scrollbar-none">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 px-4 py-3.5 text-sm font-medium border-b-2 whitespace-nowrap transition-all ${
                    isActive
                      ? `border-current ${tab.color}`
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  <Icon size={15} />
                  <span className="hidden sm:inline">{tab.label}</span>
                  <span className="sm:hidden">{tab.shortLabel}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* ─── Main Content ─── */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "rooms" && <RoomMonitoring />}
        {activeTab === "energy" && <EnergyAnalytics />}
        {activeTab === "marketplace" && <GreenMarketplace />}
        {activeTab === "report" && <HODReport />}
      </main>

      {/* ─── Footer ─── */}
      <footer className="border-t border-gray-200 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between flex-wrap gap-2">
          <p className="text-xs text-gray-400">
            © {new Date().getFullYear()} EcoPulse Vision Guard · Powered by{" "}
            <span className="text-blue-500 font-medium">IBM Granite AI</span> &{" "}
            <span className="text-green-500 font-medium">watsonx.ai</span>
          </p>
          <p className="text-xs text-gray-400">
            1 kWh saved = 10 Credits · 100 Credits = $1.00
          </p>
        </div>
      </footer>
    </div>
  );
}

function StatusPill({
  icon,
  label,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  color: "green" | "blue" | "purple";
}) {
  const colorMap = {
    green: "bg-green-50 text-green-600 border-green-200",
    blue: "bg-blue-50 text-blue-600 border-blue-200",
    purple: "bg-purple-50 text-purple-600 border-purple-200",
  };
  return (
    <span
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-medium ${colorMap[color]}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
      {icon}
      {label}
    </span>
  );
}
