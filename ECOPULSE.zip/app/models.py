"""
SQLAlchemy ORM models for EcoPulse Vision Guard.
Supports PostgreSQL (prod) and SQLite (local dev via DATABASE_URL env var).
"""

from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Float, DateTime, ForeignKey, Enum, Text, Boolean
)
from sqlalchemy.orm import relationship, declarative_base

Base = declarative_base()


class Department(Base):
    __tablename__ = "departments"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False, unique=True)
    hod_email = Column(String(255), nullable=False)
    credit_balance = Column(Float, default=0.0, nullable=False)

    rooms = relationship("Room", back_populates="department")
    meter_readings = relationship("MeterReading", back_populates="department")
    daily_reports = relationship("DailyReport", back_populates="department")

    def __repr__(self) -> str:
        return f"<Department id={self.id} name={self.name!r}>"


class Room(Base):
    __tablename__ = "rooms"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    status = Column(Enum("ON", "OFF", name="room_status"), default="OFF", nullable=False)
    last_occupied_time = Column(DateTime, nullable=True)
    cctv_stream_url = Column(String(512), nullable=True)
    # Seconds of continuous zero-occupancy since last person detected
    empty_seconds = Column(Integer, default=0, nullable=False)

    department = relationship("Department", back_populates="rooms")
    meter_readings = relationship("MeterReading", back_populates="room")

    def __repr__(self) -> str:
        return f"<Room id={self.id} name={self.name!r} status={self.status}>"


class MeterReading(Base):
    __tablename__ = "meter_readings"

    id = Column(Integer, primary_key=True, index=True)
    room_id = Column(Integer, ForeignKey("rooms.id"), nullable=False)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    kwh_value = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    image_url = Column(String(512), nullable=True)
    # OCR-extracted raw text from the meter image
    raw_ocr_text = Column(Text, nullable=True)
    # Embedding vector stored externally in pgvector/Milvus; store the doc id here
    vector_doc_id = Column(String(128), nullable=True)

    room = relationship("Room", back_populates="meter_readings")
    department = relationship("Department", back_populates="meter_readings")


class MarketplaceProduct(Base):
    __tablename__ = "marketplace_products"

    id = Column(Integer, primary_key=True, index=True)
    product_name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    original_price = Column(Float, nullable=False)          # USD
    credit_discount_price = Column(Float, nullable=False)   # USD after discount
    required_credits = Column(Integer, nullable=False)      # EcoPulse Credits
    stock = Column(Integer, default=100, nullable=False)
    category = Column(String(80), nullable=True)            # e.g., "Lighting", "Appliances"
    image_url = Column(String(512), nullable=True)

    def __repr__(self) -> str:
        return f"<MarketplaceProduct id={self.id} name={self.product_name!r}>"


class DailyReport(Base):
    __tablename__ = "daily_reports"

    id = Column(Integer, primary_key=True, index=True)
    department_id = Column(Integer, ForeignKey("departments.id"), nullable=False)
    date = Column(DateTime, nullable=False)
    kwh_consumed = Column(Float, default=0.0)
    kwh_saved = Column(Float, default=0.0)
    cost_saved = Column(Float, default=0.0)                 # USD
    co2_reduced = Column(Float, default=0.0)                # kg CO2
    credits_earned = Column(Float, default=0.0)
    summary_text = Column(Text, nullable=True)
    report_pdf_url = Column(String(512), nullable=True)
    email_sent = Column(Boolean, default=False)

    department = relationship("Department", back_populates="daily_reports")
