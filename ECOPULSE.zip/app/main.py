"""
EcoPulse Vision Guard — FastAPI Backend
========================================
Endpoints:
  /api/rooms                GET    - list all rooms with live status
  /api/rooms/{id}/analyze   POST   - upload camera frame → occupancy analysis + relay
  /api/meter/upload         POST   - upload meter image → OCR → store reading
  /api/meter/readings       GET    - paginated meter readings
  /api/departments          GET    - list departments + credit balances
  /api/marketplace          GET    - list redeemable eco-products
  /api/marketplace/redeem   POST   - redeem credits for a product
  /api/reports/generate     POST   - trigger HOD end-of-day report
  /api/reports/{dept_id}    GET    - fetch latest reports for a department
  /ws/rooms                 WS     - WebSocket live occupancy + relay push feed
"""

import asyncio
import json
import logging
import os
import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import (
    FastAPI, Depends, File, Form, HTTPException, UploadFile, WebSocket,
    WebSocketDisconnect, BackgroundTasks,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session

from .database import get_db, init_db, upsert_meter_vector, search_similar_readings
from .models import (
    Department, Room, MeterReading, MarketplaceProduct, DailyReport,
)
from .agent import (
    process_occupancy_event,
    extract_meter_reading,
    generate_hod_report,
    award_credits,
    calculate_credits,
    CREDITS_PER_KWH,
    CO2_KG_PER_KWH,
    COST_PER_KWH_USD,
)

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# App bootstrap
# ---------------------------------------------------------------------------
app = FastAPI(
    title="EcoPulse Vision Guard API",
    description="Automated campus energy control, monitoring & sustainability loyalty platform",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # tighten in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    init_db()
    _seed_demo_data()
    logger.info("EcoPulse Vision Guard API started ✓")


# ---------------------------------------------------------------------------
# Demo seed data (idempotent)
# ---------------------------------------------------------------------------
def _seed_demo_data():
    from .database import SessionLocal
    db = SessionLocal()
    try:
        if db.query(Department).count() > 0:
            return

        depts = [
            Department(name="Computer Science & Engineering", hod_email="hod.cse@campus.edu", credit_balance=450),
            Department(name="Electrical Engineering", hod_email="hod.ee@campus.edu", credit_balance=820),
            Department(name="Mechanical Engineering", hod_email="hod.mech@campus.edu", credit_balance=230),
        ]
        db.add_all(depts)
        db.flush()

        rooms = [
            Room(name="LAB-101", department_id=depts[0].id, status="ON",
                 last_occupied_time=datetime.utcnow(),
                 cctv_stream_url="rtsp://campus.local/cse/lab101"),
            Room(name="LAB-102", department_id=depts[0].id, status="OFF",
                 cctv_stream_url="rtsp://campus.local/cse/lab102"),
            Room(name="AUDITORIUM-A", department_id=depts[0].id, status="ON",
                 last_occupied_time=datetime.utcnow(),
                 cctv_stream_url="rtsp://campus.local/cse/audi-a"),
            Room(name="DEPT-CSE-OFFICE", department_id=depts[0].id, status="OFF",
                 cctv_stream_url="rtsp://campus.local/cse/office"),
            Room(name="EE-LAB-201", department_id=depts[1].id, status="ON",
                 last_occupied_time=datetime.utcnow(),
                 cctv_stream_url="rtsp://campus.local/ee/lab201"),
            Room(name="MECH-WORKSHOP", department_id=depts[2].id, status="OFF",
                 cctv_stream_url="rtsp://campus.local/mech/workshop"),
        ]
        db.add_all(rooms)
        db.flush()

        # Seed marketplace products
        products = [
            MarketplaceProduct(product_name="Smart LED Strip (5m)", original_price=24.99,
                               credit_discount_price=14.99, required_credits=100,
                               category="Lighting", stock=50,
                               description="Energy Star certified LED strip, 5m, RGB+W"),
            MarketplaceProduct(product_name="Energy Star Desktop Fan", original_price=49.99,
                               credit_discount_price=34.99, required_credits=150,
                               category="Appliances", stock=30,
                               description="Low-power smart fan with occupancy sensor"),
            MarketplaceProduct(product_name="Recycled Office Paper (500 sheets)", original_price=8.99,
                               credit_discount_price=4.99, required_credits=40,
                               category="Stationery", stock=200,
                               description="100% post-consumer recycled A4 paper"),
            MarketplaceProduct(product_name="Smart Power Strip (6-outlet)", original_price=39.99,
                               credit_discount_price=24.99, required_credits=150,
                               category="Appliances", stock=40,
                               description="Auto-shutoff smart power strip saves standby power"),
            MarketplaceProduct(product_name="Solar Phone Charger", original_price=29.99,
                               credit_discount_price=17.99, required_credits=120,
                               category="Electronics", stock=25,
                               description="Portable 10W solar charger for mobile devices"),
            MarketplaceProduct(product_name="Reusable Water Bottle (BPA-Free)", original_price=14.99,
                               credit_discount_price=7.99, required_credits=70,
                               category="Sustainability", stock=100,
                               description="Stainless steel insulated bottle, 750ml"),
        ]
        db.add_all(products)

        # Seed sample meter readings for RAG context
        for i, room in enumerate(rooms[:4]):
            reading = MeterReading(
                room_id=room.id,
                department_id=room.department_id,
                kwh_value=round(2.5 + i * 0.8, 2),
                timestamp=datetime.utcnow(),
                raw_ocr_text=f"kWh: {2.5 + i * 0.8:.1f}",
                vector_doc_id=str(uuid.uuid4()),
            )
            db.add(reading)
            db.flush()
            upsert_meter_vector(
                doc_id=reading.vector_doc_id,
                kwh=reading.kwh_value,
                timestamp=reading.timestamp.isoformat(),
                room_id=reading.room_id,
                raw_text=reading.raw_ocr_text,
            )

        db.commit()
        logger.info("Demo seed data loaded ✓")
    except Exception as exc:
        db.rollback()
        logger.warning("Seed data skipped: %s", exc)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Pydantic schemas
# ---------------------------------------------------------------------------
class RoomOut(BaseModel):
    id: int
    name: str
    department_id: int
    status: str
    last_occupied_time: Optional[datetime]
    cctv_stream_url: Optional[str]
    empty_seconds: int

    class Config:
        from_attributes = True


class DeptOut(BaseModel):
    id: int
    name: str
    hod_email: str
    credit_balance: float

    class Config:
        from_attributes = True


class MeterReadingOut(BaseModel):
    id: int
    room_id: int
    department_id: int
    kwh_value: float
    timestamp: datetime
    image_url: Optional[str]
    raw_ocr_text: Optional[str]

    class Config:
        from_attributes = True


class ProductOut(BaseModel):
    id: int
    product_name: str
    description: Optional[str]
    original_price: float
    credit_discount_price: float
    required_credits: int
    stock: int
    category: Optional[str]

    class Config:
        from_attributes = True


class RedeemRequest(BaseModel):
    department_id: int
    product_id: int
    quantity: int = 1


class ReportRequest(BaseModel):
    department_id: int


class ManualRelayRequest(BaseModel):
    action: str  # "POWER_ON" | "POWER_OFF"


# ---------------------------------------------------------------------------
# WebSocket connection manager
# ---------------------------------------------------------------------------
class ConnectionManager:
    def __init__(self):
        self.active: List[WebSocket] = []

    async def connect(self, ws: WebSocket):
        await ws.accept()
        self.active.append(ws)

    def disconnect(self, ws: WebSocket):
        self.active.remove(ws)

    async def broadcast(self, data: dict):
        dead = []
        for ws in self.active:
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.active.remove(ws)


manager = ConnectionManager()


# ---------------------------------------------------------------------------
# Routes — Rooms
# ---------------------------------------------------------------------------
@app.get("/api/rooms", response_model=List[RoomOut], tags=["Rooms"])
def list_rooms(db: Session = Depends(get_db)):
    return db.query(Room).all()


@app.get("/api/rooms/{room_id}", response_model=RoomOut, tags=["Rooms"])
def get_room(room_id: int, db: Session = Depends(get_db)):
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(404, "Room not found")
    return room


@app.post("/api/rooms/{room_id}/relay", tags=["Rooms"])
def manual_relay(room_id: int, req: ManualRelayRequest, db: Session = Depends(get_db)):
    """Manually override a room's relay state."""
    from .agent import trigger_relay
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(404, "Room not found")
    room.status = "ON" if req.action == "POWER_ON" else "OFF"
    if req.action == "POWER_ON":
        room.last_occupied_time = datetime.utcnow()
    db.commit()
    result = trigger_relay(room_id, room.name, req.action)
    return {"ok": True, "relay": result}


@app.post("/api/rooms/{room_id}/analyze", tags=["Rooms"])
async def analyze_room_frame(
    room_id: int,
    frame: UploadFile = File(...),
    background_tasks: BackgroundTasks = BackgroundTasks(),
    db: Session = Depends(get_db),
):
    """
    Upload a CCTV frame JPEG → IBM Granite Vision occupancy analysis.
    Triggers MQTT relay if threshold conditions are met.
    """
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(404, "Room not found")

    image_bytes = await frame.read()
    result = await process_occupancy_event(room_id, room.name, image_bytes, db)

    # Broadcast live update via WebSocket
    await manager.broadcast({
        "event": "occupancy_update",
        "data": result,
    })
    return result


# ---------------------------------------------------------------------------
# Routes — Meter Readings
# ---------------------------------------------------------------------------
@app.post("/api/meter/upload", response_model=MeterReadingOut, tags=["Meter"])
async def upload_meter_image(
    room_id: int = Form(...),
    department_id: int = Form(...),
    image: UploadFile = File(...),
    db: Session = Depends(get_db),
):
    """Upload a meter photo → OCR via IBM Granite Vision → store reading."""
    image_bytes = await image.read()

    ocr = await extract_meter_reading(image_bytes)
    kwh = ocr["kwh"]

    doc_id = str(uuid.uuid4())
    reading = MeterReading(
        room_id=room_id,
        department_id=department_id,
        kwh_value=kwh,
        timestamp=datetime.utcnow(),
        raw_ocr_text=ocr["raw_text"],
        vector_doc_id=doc_id,
    )
    db.add(reading)
    db.commit()
    db.refresh(reading)

    upsert_meter_vector(
        doc_id=doc_id,
        kwh=kwh,
        timestamp=reading.timestamp.isoformat(),
        room_id=room_id,
        raw_text=ocr["raw_text"],
    )

    await manager.broadcast({"event": "meter_update", "data": {
        "room_id": room_id, "kwh": kwh, "timestamp": reading.timestamp.isoformat()
    }})
    return reading


@app.get("/api/meter/readings", response_model=List[MeterReadingOut], tags=["Meter"])
def get_meter_readings(
    department_id: Optional[int] = None,
    room_id: Optional[int] = None,
    limit: int = 50,
    db: Session = Depends(get_db),
):
    q = db.query(MeterReading)
    if department_id:
        q = q.filter(MeterReading.department_id == department_id)
    if room_id:
        q = q.filter(MeterReading.room_id == room_id)
    return q.order_by(MeterReading.timestamp.desc()).limit(limit).all()


@app.get("/api/meter/baseline", tags=["Meter"])
def get_rag_baseline(room_id: int, kwh: float):
    """Return historically similar readings for RAG context."""
    query_text = f"room {room_id} kwh {kwh}"
    results = search_similar_readings(query_text)
    return {"similar_readings": results}


# ---------------------------------------------------------------------------
# Routes — Departments
# ---------------------------------------------------------------------------
@app.get("/api/departments", response_model=List[DeptOut], tags=["Departments"])
def list_departments(db: Session = Depends(get_db)):
    return db.query(Department).all()


@app.get("/api/departments/{dept_id}", response_model=DeptOut, tags=["Departments"])
def get_department(dept_id: int, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.id == dept_id).first()
    if not dept:
        raise HTTPException(404, "Department not found")
    return dept


# ---------------------------------------------------------------------------
# Routes — Marketplace
# ---------------------------------------------------------------------------
@app.get("/api/marketplace", response_model=List[ProductOut], tags=["Marketplace"])
def list_products(
    category: Optional[str] = None,
    max_credits: Optional[int] = None,
    db: Session = Depends(get_db),
):
    q = db.query(MarketplaceProduct).filter(MarketplaceProduct.stock > 0)
    if category:
        q = q.filter(MarketplaceProduct.category == category)
    if max_credits is not None:
        q = q.filter(MarketplaceProduct.required_credits <= max_credits)
    return q.order_by(MarketplaceProduct.required_credits).all()


@app.post("/api/marketplace/redeem", tags=["Marketplace"])
def redeem_product(req: RedeemRequest, db: Session = Depends(get_db)):
    dept = db.query(Department).filter(Department.id == req.department_id).first()
    product = db.query(MarketplaceProduct).filter(MarketplaceProduct.id == req.product_id).first()

    if not dept:
        raise HTTPException(404, "Department not found")
    if not product:
        raise HTTPException(404, "Product not found")
    if product.stock < req.quantity:
        raise HTTPException(400, f"Insufficient stock: {product.stock} available")

    total_credits = product.required_credits * req.quantity
    if dept.credit_balance < total_credits:
        raise HTTPException(400, f"Insufficient credits: need {total_credits}, have {dept.credit_balance:.0f}")

    dept.credit_balance -= total_credits
    product.stock -= req.quantity
    db.commit()

    return {
        "ok": True,
        "product": product.product_name,
        "quantity": req.quantity,
        "credits_spent": total_credits,
        "remaining_balance": dept.credit_balance,
        "savings_usd": round((product.original_price - product.credit_discount_price) * req.quantity, 2),
    }


# ---------------------------------------------------------------------------
# Routes — HOD Report
# ---------------------------------------------------------------------------
@app.post("/api/reports/generate", tags=["Reports"])
async def generate_report(req: ReportRequest, db: Session = Depends(get_db)):
    """Trigger IBM Granite RAG-powered HOD End-of-Day report generation."""
    similar = search_similar_readings(f"department {req.department_id} daily summary")
    report = await generate_hod_report(req.department_id, db, similar)
    return report


@app.get("/api/reports/{dept_id}", tags=["Reports"])
def get_reports(dept_id: int, limit: int = 10, db: Session = Depends(get_db)):
    reports = (
        db.query(DailyReport)
        .filter(DailyReport.department_id == dept_id)
        .order_by(DailyReport.date.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "id": r.id,
            "date": r.date.isoformat(),
            "kwh_consumed": r.kwh_consumed,
            "kwh_saved": r.kwh_saved,
            "cost_saved": r.cost_saved,
            "co2_reduced": r.co2_reduced,
            "credits_earned": r.credits_earned,
            "summary": r.summary_text,
        }
        for r in reports
    ]


# ---------------------------------------------------------------------------
# Analytics endpoint
# ---------------------------------------------------------------------------
@app.get("/api/analytics/energy", tags=["Analytics"])
def energy_analytics(department_id: Optional[int] = None, db: Session = Depends(get_db)):
    """Return hourly energy consumption for charts (last 24h)."""
    from sqlalchemy import func
    from datetime import timedelta

    since = datetime.utcnow() - timedelta(hours=24)
    q = db.query(MeterReading).filter(MeterReading.timestamp >= since)
    if department_id:
        q = q.filter(MeterReading.department_id == department_id)

    readings = q.order_by(MeterReading.timestamp).all()

    # Group by hour
    hourly: dict = {}
    for r in readings:
        key = r.timestamp.strftime("%H:00")
        hourly.setdefault(key, {"hour": key, "kwh": 0, "count": 0})
        hourly[key]["kwh"] = round(hourly[key]["kwh"] + r.kwh_value, 3)
        hourly[key]["count"] += 1

    total_kwh = sum(v["kwh"] for v in hourly.values())
    credits_equivalent = calculate_credits(total_kwh * 0.15)   # assume 15% savings

    return {
        "hourly": list(hourly.values()),
        "total_kwh_24h": round(total_kwh, 3),
        "estimated_savings_kwh": round(total_kwh * 0.15, 3),
        "credits_earned_today": credits_equivalent,
        "cost_saved_usd": round(total_kwh * 0.15 * COST_PER_KWH_USD, 2),
        "co2_reduced_kg": round(total_kwh * 0.15 * CO2_KG_PER_KWH, 3),
    }


# ---------------------------------------------------------------------------
# WebSocket — live feed
# ---------------------------------------------------------------------------
@app.websocket("/ws/rooms")
async def ws_rooms(websocket: WebSocket, db: Session = Depends(get_db)):
    """
    Push real-time room occupancy + relay events to connected dashboard clients.
    Clients receive JSON events: {event: "occupancy_update"|"meter_update", data: {...}}
    """
    await manager.connect(websocket)
    try:
        # Send initial state snapshot
        rooms = db.query(Room).all()
        await websocket.send_json({
            "event": "snapshot",
            "data": [
                {
                    "id": r.id, "name": r.name, "status": r.status,
                    "department_id": r.department_id,
                    "last_occupied_time": r.last_occupied_time.isoformat()
                    if r.last_occupied_time else None,
                }
                for r in rooms
            ],
        })
        while True:
            # Keep connection alive; actual pushes come from analyze_room_frame
            await asyncio.sleep(30)
            await websocket.send_json({"event": "ping"})
    except WebSocketDisconnect:
        manager.disconnect(websocket)


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------
@app.get("/health", tags=["System"])
def health():
    return {"status": "ok", "service": "EcoPulse Vision Guard", "timestamp": datetime.utcnow().isoformat()}
